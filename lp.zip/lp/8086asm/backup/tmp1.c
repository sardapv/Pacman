#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "main.h"

#define MAX_OP 18
#define MAX_IM 11
#define MAX_AD 5
#define MAX_DL 2

char search_optab(char *string) {
  unsigned char i;

  for (i = 0; i < MAX_OP; i++) {
    if (!strcmp(string, optab[i])) {
      return i; // location of the string
    }
  }

  return -1;    // represent value does not exist
}

// TODO : ERROR HANDLING DURING READING OF THE FILE and ERROR SHOULD BE HANDLED BY ANOTHER FUNCTION SPECIFICALLY FOR ERROR HANDLING
// Checks as per the standard instruction format of the assembly language
char check_category(char *string, char index) {
  switch(index) {
  case LABEL:
    return (search_optab(strupr(string)) + 1)? INSTRUCTION: LABEL;
  case INSTRUCTION:
    return INSTRUCTION;
  case OPERAND:
    return OPERAND;
  case OPERAND + 1:
    return OPERAND + 1;
  default:
    return ERROR;
  }

}

// Reads the instruction line by line and checks for the standaud format of the instruction
char read_split_fill(FILE *asmfile, char *label, char *instruction, char *operand1, char *operand2) {
  #define MAX_STMT_LEN 128

  char index, buffer[MAX_STMT_LEN], ch, prev_ch;
  unsigned char i;

  index = 0;
  i = 0;
  prev_ch = ' ';
  label[0] = '\0';
  operand1[0] = '\0';
  operand2[0] = '\0';

  while((ch = fgetc(asmfile)) || 1) {
    if (!((prev_ch ^ ' ' && prev_ch ^ ',' && prev_ch ^ '\n') || (ch ^ ' ' && ch ^ '\n' && ch ^ ',')))
      continue;
    prev_ch = ch;
    if (!((ch ^ ' ') && (ch ^ ',') &&  (ch ^ '\n') && (ch ^ EOF))) {
        buffer[i] = '\0';

	switch(check_category(buffer, index)) {
  	  case LABEL:
            strcpy(label, buffer);
	    break;
	  case INSTRUCTION:
            strcpy(instruction, buffer);
	    break;
	  case OPERAND:
            strcpy(operand1, buffer);    
            break;
	  case OPERAND+1:
	    strcpy(operand2, buffer);
	    break;
	  default:
	    printf("Error occurred\n");
	    break;
        }

        // return error_check(label, instruction, operand1, operand2, index)  complete it
        if(!(ch ^ EOF)) {
	  return EOF;
	}
	else if(!(ch ^ '\n'))
	  break;

        i = 0;
        index++;
	if (!label[0])
	  index++;
    }
    else  {
      buffer[i++] = ch;
    }
  } 
 
  return 0;
}

void insert_into_symtab(char *label, int address) {
  int i;

  for (i = 0; i < symtab_counter; i++) {
    if (!strcmp(symbol[i].label, label)) {
      if (symbol[i].address == NO_ADDRESS)
	break;
      else {
	// error_generator("Duplicate Reference");	
	return;
        // return error more than one times reference or ambigous label since repeated
      }
    }

  }
  strcpy(symbol[i].label, label);
  symbol[i].address = location_counter;
  symtab_counter++;
}
void insert_into_littab(int literal, int address) {
  int i;

  for (i = 0; i < littab_counter; i++) {
    if (littab[i].literal == literal) {
      if (littab[i].address == NO_ADDRESS)
	break;
      else;
      //call the error function double reference
    }
  }
  littab[i].literal = literal;
  littab[i].address = address;
}


// checks that given label is register or not in case of the operand
// returns 0 incase of absence and non-zero or reg value if string is register
char isregister(char *string) {
  int i;

  for (i = 0; i < MAX_REG; i++)
    if(!strcmp(string, reg[i]))
      return i;
  return 0; // It is not register
}
// checks that given label is actually label or not 
char search_or_insert_label(char *string) {
  int i;

  for (i = 0; i < symtab_counter; i++) {
    if(!strcmp(symbol[i].label, string))
      return i;
  }
  strcpy(symbol[i].label, string);
  symbol[i].address = NO_ADDRESS;
  return i;
}

char pass_one(FILE *asmfile, FILE *icfile) {
  char label[16], instruction[16], operand1[16], operand2[16], opcode, reg;
  int count;

  symtab_counter = 0;
  littab_counter = 0;
  while(!read_split_fill(asmfile, label, instruction, operand1, operand2)) {
    printf(">> L:%-10s I:%-10s O:%-5s O:%-5s\n", label, instruction, operand1, operand2);
    if (label[0] && label[0] ^ '=') {
      //insert label and addr
      insert_into_symtab(label, location_counter);
    }
    if (!(label[0] ^ '=')) {//Hancling of the LTORG and END statement literals
      //insert into literal table
      insert_into_littab(atoi(&label[2]), location_counter);
      location_counter += SIZE_LTORG;
    }
    else if (!strcmp(strupr(instruction), "START")) {
      //handle error of the double start stmt by adding the flag 
      //initialize the location counter
      if (operand1[0])
	location_counter = atoi(operand1);
      else;
	//call error function
    }
    else if(!strcmp(strupr(instruction), "EQU")) {
      //assign value to label
      if (operand1[0] && !isdigit(operand1[0])) {
	insert_into_symtab(label, -1);
        insert_into_symtab(operand1, -1);
      }
      else if (operand1[0]) //if operand is not label
	insert_into_symtab(label, atoi(operand1));
      else;
	  //call error function

      location_counter += SIZE_AD;
    }
    else if ((opcode=search_optab(instruction)) < MAX_IM) {
      //imperative stmt handle accordingly
      fprintf(icfile, "%5d (IS,%2d) ", location_counter, opcode);
      if (operand1[0]) {
	if ((reg = isregister(strupr(operand1)))) {
	  fprintf(icfile, "(%d)", reg);
	}
	else if (!(operand1[0] ^ '=')) {
	  fprintf(icfile, "(L,%5d)", ++littab_counter);
	  insert_into_littab(atoi(&operand1[2]), NO_ADDRESS);
	}
	else if ((count = search_or_insert_label(operand1))) {
	  fprintf(icfile, "(S,%5d)", count);
	}
	else;
	//call error function
	
      }
      if (operand2[0]) {
	if (!(operand2[0] ^ '=')) {
	  fprintf(icfile, "(L,%5d)", atoi(&operand2[2]));
	}
	else if ((count = search_or_insert_label(operand2))) {
	  fprintf(icfile, "(S,%5d)", count);
	}
	else;
	//call error function
      }
      fprintf(icfile, "\n");
      // check error for every other instruction
      location_counter += SIZE_IM;
    }
    else if ((opcode=search_optab(instruction)) > (MAX_IM+MAX_AD-1)) {
      //declarative stmt handle accordingly
      if (operand1[0]) {
	fprintf(icfile, "%5d (DL,%2d) (C,%5d)\n", location_counter, (opcode-15), atoi(operand1));
        location_counter += SIZE_DL;
      }
      else;
	//call error function
    }
    else
      printf("else\n");
  }

  return 0;
}

// Opens the file as per requirement
char fileopen(FILE **fp1, FILE **fp2, char *filename) {
  #define FILE_OPEN_ERROR 1

  char icfile[16];
  
  if ((*fp1 = fopen(filename, "r")) == NULL)
    return FILE_OPEN_ERROR;
  sprintf(icfile, "%s.i", filename);
  if ((*fp2 = fopen(icfile, "w")) == NULL)
    return FILE_OPEN_ERROR;
  return 0;
}
int main(int argc, char *argv[]) {
  char cmd[64];
  FILE *asmfile, *icfile;

  if (fileopen(&asmfile, &icfile, argv[1]))
    printf("File Error\n");

  if (pass_one(asmfile, icfile))
    //    printf("Error occurred\n");

#ifdef PASS_ONE_OUTPUT
  sprintf(cmd, "cat %s.i", argv[1]);
  system(cmd);
#endif

  fcloseall();
  return 0;
}
