#include <stdio.h>


/*optab = {
         // ENTRIES FOR 'IMPERATIVE STMT'
         {"STOP", 00},
	 {"ADD",  01},
	 {"SUB",  02},
	 {"MULT", 03},
	 {"MOVEM",04, 1},
         {"MOVER",05, 1},
	 {"COMP", 06, 1},
	 {"BC",   07},
	 {"DIV",  08},
	 {"READ", 09},
	 {"PRINT",10},

	 // ENTRIES FOR 'ASSEMBLER DIRECTIVE'
	 {"START", 01},
	 {"END",   02},
	 {"ORIGIN",03},
	 {"EQU",   04},
	 {"LTORG", 05}

	 // ENTRIES FOR 'DECLARATIVE STMT'
	 {"DS", 01, },
	 {"DC", 02, },
        }
*/
int main(int argc, char *argv[]) {
  char s[100];
  FILE *asmfile, *icfile;

  icfile = fopen(".tmp.i", "r");
  fscanf(icfile, "%s", s);
  
  fprintf(stdout, "%s\n", s);

  while(1) {
  fscanf(icfile, "%s", s);
  if (s[strlen(s)-1]=='\n')
    break;
  
  fprintf(stdout, "%s\n", s);
  getchar();
  }
  /*
  fscanf(icfile, "%s", s);
  fprintf(stdout, "%s\n", s);

  fscanf(icfile, "%s", s);
  fprintf(stdout, "%s\n", s);

  fscanf(icfile, "%s", s);
  fprintf(stdout, "%s\n", s);
  */
  fcloseall();
  return 0;
}
