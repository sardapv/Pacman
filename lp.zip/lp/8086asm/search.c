#include "main.h"

char search_optab(char *string) {
  unsigned char i;

  for (i = 0; i < MAX_OP; i++) {
    if (!strcmp(string, optab[i])) {
      return i; // location of the string
    }
  }

  return -1;    // represent value does not exist
}

// TODO : ERROR HANDLING DURING READING OF THE FILE and ERROR SHOULD BE HANDLED BY ANOTHER FUNCTION SPECIFICALLY FOR ERROR HANDLING
// Checks as per the standard instruction format of the assembly language
char check_category(char *string, char index) {
  int ret;
  switch(index) {
  case LABEL:
    ret =  (search_optab(strupr(string)) + 1)? INSTRUCTION: LABEL;
    break;
  case INSTRUCTION:
    ret = INSTRUCTION;
    break;
  case OPERAND:
    ret = OPERAND;
    break;
  case OPERAND + 1:
    ret = OPERAND + 1;
    break;
  default:
    ret = ERROR;
    break;
  }
  return ret;

}

// checks that given label is register or not in case of the operand
// returns 0 incase of absence and non-zero or reg value if string is register
char isregister(char *string) {
  int i;

  for (i = 0; i < MAX_REG; i++)
    if(!strcmp(string, reg[i]))
      return i+1;
  return 0; // It is not register
}

// checks that given label is actually label or not 
char search_or_insert_label(char *string) {
  int i;

  for (i = 0; i < symtab_counter; i++) {
    if(!strcmp(symbol[i].label, string))
      return i;
  }
  strcpy(symbol[i].label, string);
  symbol[i].address = NO_ADDRESS;

  symtab_counter++;
  return i;
}

// checks for gt, ge, le, lt
char search_bc(char *string) {
  int i;
  char *bc[] = {"LE",  "LT", "GE", "GT"};
 
  for (i=0; i < 4; i++) {
    if (!strcmp(bc[i], string))
	return i+1;
  }
  return 0;
}
