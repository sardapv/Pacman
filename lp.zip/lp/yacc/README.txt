here first compile lex code then yacc code & then the C file. 

following are the commands: (you might need to change te commands depending on your machine, some issues might occure in case of Virtual Machine)

lex Lex.l

bison/yacc Yacc.y

gcc Yacc.tab.c -ll -ly -lm


5+6
=11
5