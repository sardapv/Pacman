#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define itoa(x) x

typedef struct MNT{
	char name[8];
	int no_para;
	int si;
}MNT;

typedef struct MDT{
	char entry[16];
}MDT;

typedef struct PARATAB{
	char para[8];
	int pos;
}PARATAB;



void printMNT(MNT mnt[], int mi){
	int i;
	printf("\tMNT : \n");
	for(i = 0; i < mi; i++){
		printf("%s\t%d\t%d\n", mnt[i].name, mnt[i].no_para, mnt[i].si);
	}
}
void printMDT(MDT mdt[], int mi){
	int i;
	printf("\tMDT : \n");
	for(i = 0; i < mi; i++){
		printf("%d  %s\n", i, mdt[i].entry);
	}
}
void printPARATAB(PARATAB pt[], int pi){
	int i;
	printf("\tPARATAB : \n");
	for(i = 0; i < pi; i++){
		printf("%s\t%d\n", pt[i].para, pt[i].pos);
	}
}
void addtoMNT(MNT mnt[], int *mni, char *name, int no_para, int si){
	strcpy(mnt[*mni].name, name);
	mnt[*mni].no_para = no_para;
	mnt[*mni].si = si;
	(*mni)++;
}
void addtoMDT(MDT mdt[], int *mdi, char *tmp){
	strcpy(mdt[*mdi].entry, tmp);
	(*mdi)++;
}
void addtoPARATAB(PARATAB pt[], int *pi, char *para, int pos){
	strcpy(pt[*pi].para, para);
	pt[*pi].pos = pos;
	(*pi)++;
}
int getPOS(PARATAB pt[], int pi, char *para){
	int i;
	for(i = 0; i < pi; i++){
		if(strcmp(para, pt[i].para) == 0){
			return i;
		}
	}
	return -1;
}
int getINDEX(MNT mnt[], int mni, char *name, int no_para){
	int i;
	for(i = 0; i < mni; i++){
		if(strcmp(name, mnt[i].name) == 0 && no_para == mnt[i].no_para){
			return mnt[i].si;
		}
	}
	return -1;
}


int main(int argc, char* argv[]){
	FILE *fp, *fpi, *fpo;

	fp = fopen("macrones1.txt", "r");
	if(!fp){
		printf("INPUT file open failed\n");
		return 0;
	}
	fpi = fopen("intermediate", "w");
	if(!fpi){
		printf("INTERMEDIATE file open failed\n");
		return 0;
	}

	MNT mnt[32];
	int mni = 0;

	MDT mdt[64];
	int mdi = 0;

	PARATAB pt[8];
	int pi = 0;

	PARATAB ptnes[8];
	int pni = 0;

	int D = 0, E = 0;
	int PC = 0;

	char line[64], oline[64], *token, ch, str[16][8], tmp[8], para[8][8], tmp1[8];
	int i, j, pos, index, k;



	//************PASS 1*************

	while(fscanf(fp, "%[^\n]%c", line, &ch) != EOF){

		for(i = 0; i < 16; i++)
			strcpy(str[i], "");

		i = 0;

		strcpy(oline, line);

		token = strtok(line, " ,\t");
		while(token){
			strcpy(str[i], token);
			i++;
			token = strtok(NULL, " ,\t");
		}
		printf("%s %s %s %s %s\n", str[0], str[1], str[2], str[3], str[4]);

		if(strcmp(str[0], "MACRO") == 0){
			D = 1;
			E = 0;
			addtoMNT(mnt, &mni, str[1], i - 2, mdi);

			for(j = 0; j < i - 2; j++)
				addtoPARATAB(pt, &pi, str[j + 2], j);
				//strcpy(para[j], str[j + 2]);
		}
		else if(D == 1 && E == 0){
			if(strcmp(str[0], "MEND") == 0){
				strcpy(tmp, str[0]);
				addtoMDT(mdt, &mdi, tmp);
				pi = 0;
				D = 0;
			}
			else{
				index = getINDEX(mnt, mni, str[0], i - 1);
				if(index != -1){
					for(j = 0; j < i - 1; j++)
						addtoPARATAB(ptnes, &pni, str[j + 1], j);
					for(j = index;; j++){
						if(strcmp(mdt[j].entry, "MEND") == 0){
							break;
						}
						strcpy(tmp, mdt[j].entry);
						i = 0;
						token = strtok(tmp, " ,\t");
						while(token){
							strcpy(str[i], token);
							i++;
							token = strtok(NULL, " ,\t");
						}
						strcpy(oline, str[0]);
						strcat(oline, " ");
						if(str[1][0] == '#'){
							strcpy(tmp, ptnes[str[1][1] - '0'].para);
							for(k = 0; k < pi; k++){
								if(strcmp(pt[k].para, tmp) == 0){
									break;
								}
							}
							sprintf(tmp, "#%d", k);
							strcat(oline, tmp);
							//strcat(oline, pt[str[1][1] - '0'].para);
						}
						else{
							strcat(oline, str[1]);
						}
						addtoMDT(mdt, &mdi, oline);
						//fprintf(fpi, "%s\n", oline);
					}
					pni = 0;
				}
				else{
					pos = getPOS(pt, pi, str[1]);
					strcpy(tmp, str[0]);
					strcat(tmp, " ");
					if(pos == -1){
						strcat(tmp, str[1]);
					}
					else{
						//*tmp1 = (char *)(itoa(pos));
						sprintf(tmp1, "#%d", pos);
						strcat(tmp, tmp1);
					}
					addtoMDT(mdt, &mdi, tmp);
				}
			}
		}
		else{
			fprintf(fpi, "%s\n", oline);
		}

	}
	printMNT(mnt, mni);
	printMDT(mdt, mdi);
	fclose(fp);
	fclose(fpi);

	fp = fopen("intermediate", "r");
	if(!fp){
		printf("INTERMEDIATE file open failed\n");
		return 0;
	}
	fpo = fopen("outputnestedmacro", "w");
	if(!fpo){
		printf("OUTPUT file open failed\n");
		return 0;
	}

	while(fscanf(fp, "%[^\n]%c", line, &ch) != EOF){

		for(i = 0; i < 16; i++)
			strcpy(str[i], "");

		i = 0;

		strcpy(oline, line);

		token = strtok(line, " ,\t");
		while(token){
			strcpy(str[i], token);
			i++;
			token = strtok(NULL, " ,\t");
		}
		//printf("%s %s %s %s %s\n", str[0], str[1], str[2], str[3], str[4]);

		index = getINDEX(mnt, mni, str[0], i - 1);
		if(index == -1){
			fprintf(fpo, "%s\n", oline);
		}
		else{
			for(j = 0; j < i - 1; j++)
				addtoPARATAB(pt, &pi, str[j + 1], j);
			for(j = index;; j++){
				if(strcmp(mdt[j].entry, "MEND") == 0){
					break;
				}
				strcpy(tmp, mdt[j].entry);
				i = 0;
				token = strtok(tmp, " ,\t");
				while(token){
					strcpy(str[i], token);
					i++;
					token = strtok(NULL, " ,\t");
				}
				strcpy(oline, str[0]);
				strcat(oline, " ");
				if(str[1][0] == '#'){
					strcat(oline, pt[str[1][1] - '0'].para);
				}
				else{
					strcat(oline, str[1]);
				}
				fprintf(fpo, "%s\n", oline);
			}
			pi = 0;
		}

	}
}
